<?php
# backwards compatibility; new sites should require OpenID.setup.php
require_once( dirname( __FILE__ ) . '/OpenID.setup.php' );
